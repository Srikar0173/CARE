import urllib.request, json, sys

def fetch(url):
    try:
        return urllib.request.urlopen(url, timeout=5).read().decode()
    except Exception as e:
        return f"ERROR: {e}"

print('CHECKING /health')
print(fetch('http://127.0.0.1:8000/health'))

print('\nCHECKING /api/dashboard')
d = fetch('http://127.0.0.1:8000/api/dashboard')
print(d[:1000])
try:
    dd=json.loads(d)
    print('DASH_KEYS:', list(dd.keys()))
except Exception as e:
    print('DASH_PARSE_ERROR', e)

print('\nCHECKING /api/priority-queue')
q = fetch('http://127.0.0.1:8000/api/priority-queue?page=1&page_size=5')
print(q[:1000])
try:
    qq=json.loads(q)
    items=qq.get('items') or []
    print('QUEUE_TOTAL:', qq.get('total'))
    if items:
        mid=items[0].get('member_id')
        print('SAMPLE_MEMBER_ID:', mid)
        mem = fetch(f'http://127.0.0.1:8000/api/members/{mid}')
        print('MEMBER:', mem[:1000])
    else:
        print('NO ITEMS')
except Exception as e:
    print('QUEUE_PARSE_ERROR', e)

print('\nFETCH ROOT HTML')
print(fetch('http://127.0.0.1:8000/'))
