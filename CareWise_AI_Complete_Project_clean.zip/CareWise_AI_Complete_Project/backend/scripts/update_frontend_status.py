"""Apply Outreach Status system updates to frontend HTML files."""
from pathlib import Path

FRONTEND = Path(__file__).resolve().parents[1] / "frontend"

def sub_file(name, replacements, label):
    p = FRONTEND / name
    html = p.read_text(encoding="utf-8")
    changed = False
    for old, new in replacements:
        if old in html:
            html = html.replace(old, new)
            changed = True
    if changed:
        p.write_text(html, encoding="utf-8")
        print(label + " updated")
    else:
        print(label + " no changes needed")

# Dashboard
sub_file("index.html", [
    ("const inProgress=contacted+followup;",
     "const inProgress=stats['In Progress']||0;" + "\n" +
     "                const statusTotal=(completed+contacted+followup+pending+inProgress)||0;" + "\n" +
     "                const statusPct=(n)=>statusTotal?Math.round((n/statusTotal)*100):0;"),
    ("setRow('Completed', completed, total?Math.round((completed/total)*100):0, 'bg-primary', 0);\n                setRow('In Progress', inProgress, total?Math.round((inProgress/total)*100):0, 'bg-secondary', 1);\n                setRow('Pending (High Priority)', pending, total?Math.round((pending/total)*100):0, 'bg-error', 2);",
     "setRow('Completed', completed, statusPct(completed), 'bg-primary', 0);\n                setRow('In Progress', inProgress, statusPct(inProgress), 'bg-secondary', 1);\n                setRow('Pending', pending, statusPct(pending), 'bg-error', 2);"),
    ("const total=d.total_members||0;\n",
     ""),
    ("<li>Pending: ${stats.Pending||0}</li><li>Contacted: ${stats.Contacted||0}</li><li>Follow-up: ${stats['Follow-up']||0}</li><li>Completed: ${stats.Completed||0}</li>",
     "<li>Pending: ${stats.Pending||0}</li><li>In Progress: ${stats['In Progress']||0}</li><li>Contacted: ${stats.Contacted||0}</li><li>Follow-up: ${stats['Follow-up']||0}</li><li>Completed: ${stats.Completed||0}</li>"),
], "Dashboard")

# Outreach queue
sub_file("outreach.html", [
    ('<option value="">All Statuses</option>\n<option value="pending">Pending</option>\n<option value="in-progress">In-Progress</option>\n<option value="contacted">Contacted</option>',
     '<option value="">All Statuses</option>\n<option value="Pending">Pending</option>\n<option value="In Progress">In Progress</option>\n<option value="Contacted">Contacted</option>\n<option value="Follow-up">Follow-up</option>\n<option value="Completed">Completed</option>'),
    ("  return String(v).toLowerCase().replace(/[ _]/g,'').replace(/[^a-z-]/g,'').replace(/-+/g,'');",
     "  var s=String(v).trim();\n  if(/^in[\\s-]*progress$/i.test(s)) return 'inprogress';\n  if(/^follow[\\s-]*up$/i.test(s)) return 'followup';\n  return s.toLowerCase().replace(/[ _-]/g,'').replace(/[^a-z]/g,'');"),
    ('<div class="w-2 h-2 rounded-full bg-[#F59E0B]"></div><span class="text-body-sm">${esc(m.outreach_status||m.status||\'\')}</span>',
     '<select class="status-select appearance-none h-8 pl-3 pr-8 bg-surface-container-lowest border border-outline-variant rounded-lg text-body-sm focus:ring-2 focus:ring-primary/20 outline-none cursor-pointer" data-member-id="${encodeURIComponent(m.member_id||m.id||\'\')}">\n          <option value="Pending" ${(m.outreach_status||m.status||\'\')===\'Pending\'?\'selected\':\'\'}>Pending</option>\n          <option value="In Progress" ${(m.outreach_status||m.status||\'\')===\'In Progress\'?\'selected\':\'\'}>In Progress</option>\n          <option value="Contacted" ${(m.outreach_status||m.status||\'\')===\'Contacted\'?\'selected\':\'\'}>Contacted</option>\n          <option value="Follow-up" ${(m.outreach_status||m.status||\'\')===\'Follow-up\'?\'selected\':\'\'}>Follow-up</option>\n          <option value="Completed" ${(m.outreach_status||m.status||\'\')===\'Completed\'?\'selected\':\'\'}>Completed</option>\n        </select>'),
    ("// delegate click for view member buttons",
     "// delegate status changes\ndocument.addEventListener('change', async(e)=>{const sel=e.target.closest('.status-select');if(sel){const mid=sel.dataset.memberId;if(!mid)return;try{const r=await fetch(API_BASE+'/api/members/'+encodeURIComponent(mid)+'/outreach-status',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:sel.value})});if(!r.ok)throw new Error('PATCH failed '+r.status);_page=1;loadQueue(1);}catch(err){console.error('Status update failed',err);loadQueue(_page);}}});\n// delegate click for view member buttons"),
], "Outreach queue")

# Member page
sub_file("member.html", [
    ('<span class="status-badge-neutral px-3 py-1 rounded-full text-label-md font-label-md flex items-center gap-1">\n<span class="material-symbols-outlined text-sm">medication</span> Diabetic\n                        </span>',
     '<span class="status-badge-neutral px-3 py-1 rounded-full text-label-md font-label-md flex items-center gap-1">\n<span class="material-symbols-outlined text-sm">medication</span> Diabetic\n                        </span>\n<div class="flex items-center gap-2">\n<select id="cw-status-select" class="appearance-none h-9 px-3 bg-surface-container-lowest border border-outline-variant rounded-lg text-body-md focus:ring-2 focus:ring-primary/20 outline-none cursor-pointer">\n<option value="Pending">Pending</option>\n<option value="In Progress">In Progress</option>\n<option value="Contacted">Contacted</option>\n<option value="Follow-up">Follow-up</option>\n<option value="Completed">Completed</option>\n</select></div>'),
    ("    const h1=document.querySelector('main h1'); setText(h1,m.member_name);",
     "    const h1=document.querySelector('main h1');setText(h1,m.member_name);\n    const stsel=document.getElementById('cw-status-select');if(stsel){stsel.value=d.outreach_status||'Pending';stsel.onchange=async(e)=>{try{const r=await fetch(API_BASE+'/api/members/'+encodeURIComponent(memberId)+'/outreach-status',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:e.target.value})});if(!r.ok)throw new Error('PATCH failed '+r.status);}catch(err){console.error('Status update failed',err);stsel.value=d.outreach_status||'Pending';}};}"),
], "Member page")

print("Frontend status updates complete")