
from typing import Any, Optional
from pydantic import BaseModel, Field

class OutreachStatusUpdate(BaseModel):
    status: str = Field(..., description="Pending, In Progress, Contacted, Follow-up, or Completed")

class CallGuideRequest(BaseModel):
    include_questions: bool = True

class HealthResponse(BaseModel):
    status: str
