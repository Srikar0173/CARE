from pathlib import Path
import hashlib
import json
import pandas as pd

BASE = Path(__file__).resolve().parents[2]
DATA_PATH = BASE / "data" / "final_member_dataset.csv"
STATUS_PATH = BASE / "data" / "outreach_status.json"

STATUS_VALUES = {"Pending", "In Progress", "Contacted", "Follow-up", "Completed"}

def _deterministic_status(member_id):
    digest = hashlib.sha256(str(member_id).encode("utf-8")).hexdigest()
    bucket = int(digest[:8], 16) % 100
    if bucket < 38:
        return "Pending"
    if bucket < 53:
        return "In Progress"
    if bucket < 68:
        return "Contacted"
    if bucket < 85:
        return "Follow-up"
    return "Completed"

class DataService:
    def __init__(self):
        self.df = pd.read_csv(DATA_PATH)
        self.df["days_since_discharge"] = self.df["days_since_discharge"].astype("float")
        self.df["total_utilization_30d"] = (
            self.df["er_visits_30d"] + self.df["hospitalizations_30d"] +
            self.df["outpatient_visits_30d"]
        )
        self.df["acute_utilization_30d"] = (
            self.df["er_visits_30d"] + self.df["hospitalizations_30d"]
        )
        self.df["social_risk_count"] = self.df[
            ["transportation_barrier","food_insecurity","housing_instability","financial_barrier"]
        ].sum(axis=1)
        self.df["post_discharge_24h"] = (
            (self.df["recent_discharge_30d"] == 1) &
            (self.df["days_since_discharge"] == 0)
        ).astype(int)
        self.df["clinical_burden"] = self.df["condition_count"]
        self.df["care_gap_burden"] = self.df["care_gap_count"]
        if not STATUS_PATH.exists():
            STATUS_PATH.write_text("{}", encoding="utf-8")
        try:
            self.status = json.loads(STATUS_PATH.read_text(encoding="utf-8"))
        except Exception:
            self.status = {}
        valid_ids = set(self.df["member_id"].astype(str))
        self.status = {k: v for k, v in self.status.items() if k in valid_ids}

    def save_status(self):
        STATUS_PATH.write_text(json.dumps(self.status, indent=2), encoding="utf-8")

    def seed_statuses_if_empty(self):
        if not self.status:
            for mid in self.df["member_id"].astype(str):
                self.status[mid] = _deterministic_status(mid)
            self.save_status()
            return
        existing_ids = set(self.status.keys())
        needed = False
        for mid in self.df["member_id"].astype(str):
            if mid not in existing_ids:
                self.status[mid] = _deterministic_status(mid)
                needed = True
        if needed:
            self.save_status()

    def get_status(self, member_id):
        return self.status.get(str(member_id), "Pending")

    def set_status(self, member_id, status):
        if status not in STATUS_VALUES:
            raise ValueError(f"Invalid status. Use one of: {sorted(STATUS_VALUES)}")
        self.status[str(member_id)] = status
        self.save_status()
        return status

    def row(self, member_id):
        rows = self.df[self.df["member_id"].astype(str) == str(member_id)]
        return None if rows.empty else rows.iloc[0]

data_service = DataService()