"""Backend-only Gemini generation for the member outreach call guide."""

import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

def _guide_response(source: str, opening_script: str, discussion_points: list[str],
                    suggested_questions: list[str], recommended_actions: list[str]) -> dict[str, Any]:
    """Expose the structured API contract and the existing UI aliases together."""
    return {
        "source": source,
        "opening_script": opening_script,
        "discussion_points": discussion_points,
        "suggested_questions": suggested_questions,
        "recommended_actions": recommended_actions,
        # Existing call-guide.html consumes these names.
        "opening": opening_script,
        "key_discussion_points": discussion_points,
        "next_actions": recommended_actions,
        "notice": "AI-generated guidance should be verified by the care manager before use.",
    }


def fallback_call_guide(member_name: str, action: str, priority_band: str,
                        member_context: dict[str, Any] | None = None) -> dict[str, Any]:
    """Deterministic fallback used whenever Gemini is unavailable or returns invalid output."""
    context = member_context or {}
    factors = context.get("risk_factors") or ["current care-management needs"]
    discussion_points = [f"Review the member's {factor.lower()}." for factor in factors[:3]]
    while len(discussion_points) < 3:
        discussion_points.append("Confirm current care-management needs and barriers to follow-up.")
    return _guide_response(
        "fallback",
        f"Hello {member_name}, this is a care manager calling to follow up on your care-management needs.",
        discussion_points,
        [
            "How are things going with your current care plan?",
            "Is there anything making it difficult to complete the recommended next step?",
            "What support would be most helpful before the next follow-up?",
            "Is there anything else you would like the care team to know?",
        ],
        [action],
    )


def _valid_guide(payload: Any) -> dict[str, Any] | None:
    """Validate Gemini output before it reaches the UI."""
    if not isinstance(payload, dict):
        return None
    keys = ("opening_script", "discussion_points", "suggested_questions", "recommended_actions")
    if not isinstance(payload.get("opening_script"), str) or not payload["opening_script"].strip():
        return None
    if any(not isinstance(payload.get(key), list) or not payload[key] for key in keys[1:]):
        return None
    if any(not all(isinstance(item, str) and item.strip() for item in payload[key]) for key in keys[1:]):
        return None
    return {
        "opening_script": payload["opening_script"].strip(),
        "discussion_points": [item.strip() for item in payload["discussion_points"][:3]],
        "suggested_questions": [item.strip() for item in payload["suggested_questions"][:4]],
        "recommended_actions": [item.strip() for item in payload["recommended_actions"][:3]],
    }


def generate_call_guide(member_name: str, priority_band: str, action: str,
                        member_context: dict[str, Any], include_questions: bool = True) -> dict[str, Any]:
    """Call Gemini with selected member data, or transparently return the rule-based fallback."""
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        return fallback_call_guide(member_name, action, priority_band, member_context)

    try:
        from google import genai
        from google.genai import types

        prompt = """Create a concise care-management outreach call guide for the supplied member data.

Use only the supplied data. Do not diagnose, invent symptoms, medications, appointments, dates, or medical history. Do not provide treatment instructions, mention model scores/probabilities, or change the provided next-best action. Keep the language respectful, practical, and appropriate for a care manager.

Member data:
""" + json.dumps({
            "member_name": member_name,
            "priority_band": priority_band,
            "next_best_action": action,
            **member_context,
        }, ensure_ascii=False)

        client = genai.Client(
            api_key=api_key,
            http_options=types.HttpOptions(timeout=20_000),
        )
        response = client.models.generate_content(
            model="gemini-3.5-flash",
            contents=prompt,
            config={
                "response_mime_type": "application/json",
                "response_json_schema": {
                    "type": "object",
                    "properties": {
                        "opening_script": {"type": "string"},
                        "discussion_points": {"type": "array", "items": {"type": "string"}, "minItems": 3, "maxItems": 3},
                        "suggested_questions": {"type": "array", "items": {"type": "string"}, "minItems": 4, "maxItems": 4},
                        "recommended_actions": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 3},
                    },
                    "required": ["opening_script", "discussion_points", "suggested_questions", "recommended_actions"],
                },
                "temperature": 0.2,
            },
        )
        parsed = getattr(response, "parsed", None)
        payload = parsed if isinstance(parsed, dict) else json.loads(response.text or "{}")
        guide = _valid_guide(payload)
        if guide:
            return _guide_response("gemini", **guide)
    except Exception as error:
        # The application must remain usable if the provider, key, or response fails.
        logger.warning(
            "Gemini call-guide generation failed (%s: %s); using fallback.",
            type(error).__name__,
            str(error),
        )
    return fallback_call_guide(member_name, action, priority_band, member_context)
