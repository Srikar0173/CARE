
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, Query, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parents[1]
PRIMARY_ENV_FILE = BACKEND_DIR / ".env"
# Local CI uses its existing isolated configuration file; prefer a normal .env
# whenever one is supplied for deployment.
load_dotenv(PRIMARY_ENV_FILE if PRIMARY_ENV_FILE.is_file() else BACKEND_DIR / "ci" / ".env")

from .services.data_service import data_service
from .services.ml_service import ml_service
from .services.action_service import next_best_action
from .services.gemini_service import generate_call_guide
from .schemas.api_models import OutreachStatusUpdate, CallGuideRequest

# In-memory prediction cache built from the real dataset/artifacts.
predictions = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global predictions
    probs, scores, bands = ml_service.initialize(data_service.df)
    data_service.df["outreach_probability"] = probs
    data_service.df["priority_score"] = scores
    data_service.df["priority_band"] = bands
    data_service.df["next_best_action"] = data_service.df.apply(next_best_action, axis=1)
    predictions = True
    yield

app = FastAPI(
    lifespan=lifespan,
    title="CareWise AI Backend",
    version="1.0.0",
    description="FastAPI backend for the Care Management Outreach Prioritization Assistant."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve the frontend from this same FastAPI application.
FRONTEND_DIR = BACKEND_DIR / "frontend"
app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

@app.get("/", include_in_schema=False)
def home():
    return FileResponse(FRONTEND_DIR / "index.html")

@app.get("/outreach", include_in_schema=False)
def outreach_page():
    return FileResponse(FRONTEND_DIR / "outreach.html")

@app.get("/member", include_in_schema=False)
def member_page():
    return FileResponse(FRONTEND_DIR / "member.html")

@app.get("/analytics", include_in_schema=False)
def analytics_page():
    return FileResponse(FRONTEND_DIR / "analytics.html")

@app.get("/call-guide", include_in_schema=False)
def call_guide_page():
    # Never serve a stale call-guide shell containing a previous member's UI.
    return FileResponse(FRONTEND_DIR / "call-guide.html", headers={"Cache-Control": "no-store"})

@app.get("/care-gaps", include_in_schema=False)
def care_gaps_page():
    return FileResponse(FRONTEND_DIR / "care-gaps.html")


# Minimal in-memory campaign store for UI workflows
campaign_store = {}

@app.get('/api/care-gaps/{field}/summary')
def care_gaps_summary(field: str):
    # field is expected to be one of the columns used for overdue flags
    df = data_service.df
    if field not in df.columns:
        raise HTTPException(status_code=404, detail='Unknown care-gap field')
    count_members = int((df[field] > 0).sum())
    open_gaps = int((df[field] > 0).sum())
    return {'field': field, 'count': count_members, 'open_gaps': open_gaps}

@app.post('/api/care-gaps/{field}/campaign')
def create_care_gap_campaign(field: str, initiator: Optional[str] = None):
    df = data_service.df
    if field not in df.columns:
        raise HTTPException(status_code=404, detail='Unknown care-gap field')
    members = df[df[field] > 0]['member_id'].astype(str).tolist()
    campaign_id = f"camp_{len(campaign_store)+1}"
    campaign_store[campaign_id] = {
        'field': field,
        'initiator': initiator,
        'member_count': len(members),
        'members_sample': members[:20]
    }
    return {'campaign_id': campaign_id, 'member_count': len(members)}

def row_to_member(row):
    return {
        "member_id": str(row["member_id"]),
        "member_name": str(row["member_name"]),
        "priority_score": round(float(row["priority_score"]), 2),
        "priority_band": str(row["priority_band"]),
        "outreach_probability": round(float(row["outreach_probability"]), 4),
        "main_risk_factors": get_risk_factors(row),
        "next_best_action": str(row["next_best_action"]),
        "outreach_status": data_service.get_status(row["member_id"]),
    }

def get_risk_factors(row):
    factors = []
    if int(row["recent_discharge_30d"]) == 1: factors.append("Recent hospital discharge")
    if int(row["er_visits_30d"]) > 0: factors.append("Recent ER utilization")
    if int(row["hospitalizations_30d"]) > 0: factors.append("Recent hospitalization")
    if int(row["care_gap_count"]) > 0: factors.append("Open care gaps")
    if int(row["medication_gap"]) == 1: factors.append("Medication gap")
    if int(row["social_risk_count"]) > 0: factors.append("Social-risk factors")
    if not factors: factors.append("Model-identified outreach factors")
    return factors[:3]

@app.get("/health")
def health():
    return {"status": "ok", "members_loaded": int(len(data_service.df))}

@app.get("/api/dashboard")
def dashboard():
    df = data_service.df
    # Build outreach status counts from the persisted status file only.
    # Do NOT assume missing statuses are 'Pending' for all members.
    raw_status = getattr(data_service, 'status', {}) or {}
    if raw_status:
        status_counts = {}
        for s in raw_status.values():
            status_counts[s] = status_counts.get(s, 0) + 1
        outreach_status_available = True
    else:
        status_counts = {}
        outreach_status_available = False

    return {
        "total_members": int(len(df)),
        "high_priority_members": int((df.priority_band == "High Priority").sum()),
        "medium_priority_members": int((df.priority_band == "Medium Priority").sum()),
        "low_priority_members": int((df.priority_band == "Low Priority").sum()),
        "average_priority_score": round(float(df.priority_score.mean()), 2),
        "members_with_open_care_gaps": int((df.care_gap_count > 0).sum()),
        "open_care_gaps": int(df.care_gap_count.sum()),
        "outreach_status": {
            "Pending": int(status_counts.get("Pending", 0)),
            "In Progress": int(status_counts.get("In Progress", 0)),
            "Contacted": int(status_counts.get("Contacted", 0)),
            "Follow-up": int(status_counts.get("Follow-up", 0)),
            "Completed": int(status_counts.get("Completed", 0)),
        },
        "outreach_status_available": outreach_status_available,
    }

@app.get("/api/members")
def members(
    q: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    sort: str = Query("priority_score_desc"),
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100)
):
    df = data_service.df.copy()
    if q:
        needle = q.lower()
        df = df[
            df["member_id"].astype(str).str.lower().str.contains(needle) |
            df["member_name"].astype(str).str.lower().str.contains(needle)
        ]
    if priority:
        df = df[df.priority_band.str.lower() == priority.lower()]
    if status:
        df = df[df.member_id.astype(str).map(data_service.get_status).str.lower() == status.lower()]

    if sort == "priority_score_asc":
        df = df.sort_values("priority_score", ascending=True)
    elif sort == "name":
        df = df.sort_values("member_name")
    else:
        df = df.sort_values("priority_score", ascending=False)

    total = len(df)
    start = (page - 1) * page_size
    items = [row_to_member(r) for _, r in df.iloc[start:start+page_size].iterrows()]
    return {"items": items, "page": page, "page_size": page_size, "total": int(total)}

@app.get("/api/priority-queue")
def priority_queue(page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=100)):
    df = data_service.df.sort_values("priority_score", ascending=False)
    total = len(df)
    start = (page - 1) * page_size
    items = [row_to_member(r) for _, r in df.iloc[start:start+page_size].iterrows()]
    return {"items": items, "page": page, "page_size": page_size, "total": int(total)}

@app.get("/api/members/{member_id}")
def member_detail(member_id: str, response: Response):
    row = data_service.row(member_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Member not found")
    response.headers["Cache-Control"] = "no-store"
    explanation = ml_service.explanation(member_id)
    return {
        "member": {
            "member_id": str(row.member_id),
            "member_name": str(row.member_name),
            "age": int(row.age),
            "diabetes": int(row.diabetes),
            "hypertension": int(row.hypertension),
            "heart_disease": int(row.heart_disease),
            "condition_count": int(row.condition_count),
        },
        "priority": {
            "score": round(float(row.priority_score), 2),
            "band": str(row.priority_band),
            "probability": round(float(row.outreach_probability), 4),
        },
        "utilization": {
            "er_visits_30d": int(row.er_visits_30d),
            "hospitalizations_30d": int(row.hospitalizations_30d),
            "outpatient_visits_30d": int(row.outpatient_visits_30d),
            "total_utilization_30d": int(row.total_utilization_30d),
            "acute_utilization_30d": int(row.acute_utilization_30d),
        },
        "care_gaps": {
            "care_gap_count": int(row.care_gap_count),
            "overdue_screening": int(row.overdue_screening),
            "overdue_lab": int(row.overdue_lab),
            "medication_gap": int(row.medication_gap),
        },
        "social_risk": {
            "transportation_barrier": int(row.transportation_barrier),
            "food_insecurity": int(row.food_insecurity),
            "housing_instability": int(row.housing_instability),
            "financial_barrier": int(row.financial_barrier),
            "social_risk_count": int(row.social_risk_count),
        },
        "discharge": {
            "recent_discharge_30d": int(row.recent_discharge_30d),
            "days_since_discharge": None if pd.isna(row.days_since_discharge) else int(row.days_since_discharge),
            "post_discharge_24h": int(row.post_discharge_24h),
        },
        "why_prioritized": explanation,
        "next_best_action": str(row.next_best_action),
        "outreach_status": data_service.get_status(member_id),
    }

@app.get("/api/members/{member_id}/explanation")
def member_explanation(member_id: str):
    if data_service.row(member_id) is None:
        raise HTTPException(status_code=404, detail="Member not found")
    result = ml_service.explanation(member_id)
    return result

@app.get("/api/members/{member_id}/next-action")
def member_next_action(member_id: str):
    row = data_service.row(member_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Member not found")
    return {"member_id": str(member_id), "next_best_action": str(row.next_best_action)}

@app.post("/api/members/{member_id}/call-guide")
def member_call_guide(member_id: str, request: CallGuideRequest = CallGuideRequest()):
    row = data_service.row(member_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Member not found")
    risk_factors = get_risk_factors(row)
    member_context = {
        "age": int(row.age),
        "conditions": {
            "diabetes": bool(row.diabetes),
            "hypertension": bool(row.hypertension),
            "heart_disease": bool(row.heart_disease),
            "condition_count": int(row.condition_count),
        },
        "utilization_last_30_days": {
            "er_visits": int(row.er_visits_30d),
            "hospitalizations": int(row.hospitalizations_30d),
            "outpatient_visits": int(row.outpatient_visits_30d),
        },
        "care_gaps": {
            "count": int(row.care_gap_count),
            "overdue_screening": bool(row.overdue_screening),
            "overdue_lab": bool(row.overdue_lab),
            "medication_gap": bool(row.medication_gap),
        },
        "social_risk": {
            "transportation_barrier": bool(row.transportation_barrier),
            "food_insecurity": bool(row.food_insecurity),
            "housing_instability": bool(row.housing_instability),
            "financial_barrier": bool(row.financial_barrier),
        },
        "discharge": {
            "recent_discharge_30d": bool(row.recent_discharge_30d),
            "days_since_discharge": None if pd.isna(row.days_since_discharge) else int(row.days_since_discharge),
        },
        "risk_factors": risk_factors,
    }
    result = generate_call_guide(
        str(row.member_name),
        str(row.priority_band),
        str(row.next_best_action),
        member_context,
        request.include_questions
    )
    # Echo the resolved row ID rather than the raw path value so the guide
    # response is always tied to the exact member used to build its prompt.
    return {"member_id": str(row.member_id), **result}

@app.patch("/api/members/{member_id}/outreach-status")
def update_outreach_status(member_id: str, payload: OutreachStatusUpdate):
    if data_service.row(member_id) is None:
        raise HTTPException(status_code=404, detail="Member not found")
    try:
        status = data_service.set_status(member_id, payload.status)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"member_id": str(member_id), "outreach_status": status}

@app.get("/api/analytics")
def analytics(cohort: Optional[str] = Query(None)):
    df = data_service.df
    # Ensure priority_band exists (added during lifespan startup)
    if "priority_band" not in df.columns:
        probs, scores, bands = ml_service.initialize(df)
        df["outreach_probability"] = probs
        df["priority_score"] = scores
        df["priority_band"] = bands
        df["next_best_action"] = df.apply(next_best_action, axis=1)
    if cohort and cohort.lower() != "all":
        df = df[df.priority_band.str.lower() == cohort.lower()]
    metrics = ml_service.metrics.to_dict(orient="records")
    priority_distribution = df["priority_band"].value_counts().to_dict()
    total = int(len(df))
    # Chronic condition prevalence from actual dataset columns
    chronic_conditions = {}
    if "hypertension" in df.columns:
        chronic_conditions["Hypertension"] = {
            "count": int((df["hypertension"] > 0).sum()),
            "percentage": round(float((df["hypertension"] > 0).mean() * 100), 1),
        }
    if "diabetes" in df.columns:
        chronic_conditions["Type 2 Diabetes"] = {
            "count": int((df["diabetes"] > 0).sum()),
            "percentage": round(float((df["diabetes"] > 0).mean() * 100), 1),
        }
    if "heart_disease" in df.columns:
        chronic_conditions["Heart Failure"] = {
            "count": int((df["heart_disease"] > 0).sum()),
            "percentage": round(float((df["heart_disease"] > 0).mean() * 100), 1),
        }
    # COPD and CKD are not present in the current dataset
    chronic_conditions["COPD"] = {"count": None, "percentage": None}
    chronic_conditions["CKD (Stages 3-5)"] = {"count": None, "percentage": None}
    # Care gap categories from actual dataset fields
    care_gap_categories = [
        {
            "category": "Overdue Screening",
            "total_identified": int((df["overdue_screening"] > 0).sum()),
            "open_count": int((df["overdue_screening"] > 0).sum()),
            "closed_count": 0,
            "closure_rate": 0.0,
        },
        {
            "category": "Overdue Lab",
            "total_identified": int((df["overdue_lab"] > 0).sum()),
            "open_count": int((df["overdue_lab"] > 0).sum()),
            "closed_count": 0,
            "closure_rate": 0.0,
        },
        {
            "category": "Medication Gap",
            "total_identified": int((df["medication_gap"] > 0).sum()),
            "open_count": int((df["medication_gap"] > 0).sum()),
            "closed_count": 0,
            "closure_rate": 0.0,
        },
    ]
    return {
        "scope": "Current Dataset",
        "dataset_name": "final_member_dataset.csv",
        "total_members": total,
        "priority_distribution": {
            "High Priority": int(priority_distribution.get("High Priority", 0)),
            "Medium Priority": int(priority_distribution.get("Medium Priority", 0)),
            "Low Priority": int(priority_distribution.get("Low Priority", 0)),
        },
        "utilization": {
            "members_with_er_visits_30d": int((df.er_visits_30d > 0).sum()),
            "members_with_hospitalizations_30d": int((df.hospitalizations_30d > 0).sum()),
            "members_with_outpatient_visits_30d": int((df.outpatient_visits_30d > 0).sum()),
            "average_er_visits_30d": round(float(df.er_visits_30d.mean()), 2),
            "average_hospitalizations_30d": round(float(df.hospitalizations_30d.mean()), 2),
            "average_outpatient_visits_30d": round(float(df.outpatient_visits_30d.mean()), 2),
            "total_er_visits_30d": int(df.er_visits_30d.sum()),
            "total_hospitalizations_30d": int(df.hospitalizations_30d.sum()),
            "total_outpatient_visits_30d": int(df.outpatient_visits_30d.sum()),
        },
        "chronic_conditions": chronic_conditions,
        "care_gaps": {
            "members_with_care_gaps": int((df.care_gap_count > 0).sum()),
            "total_care_gaps": int(df.care_gap_count.sum()),
            "members_with_overdue_screening": int((df.overdue_screening > 0).sum()),
            "members_with_overdue_lab": int((df.overdue_lab > 0).sum()),
            "members_with_medication_gap": int((df.medication_gap > 0).sum()),
            "categories": care_gap_categories,
        },
        "social_risk": {
            "transportation": int(df.transportation_barrier.sum()),
            "food_insecurity": int(df.food_insecurity.sum()),
            "housing_instability": int(df.housing_instability.sum()),
            "financial_barrier": int(df.financial_barrier.sum()),
        },
        "model_performance": metrics,
        "model_used_for_deployment": "Logistic Regression",
        "available_cohorts": ["All Cohorts", "High Priority", "Medium Priority", "Low Priority"],
    }

@app.get("/api/model-performance")
def model_performance():
    return {
        "selected_model": "Logistic Regression",
        "selection_metric": "F1",
        "models": ml_service.metrics.to_dict(orient="records")
    }


@app.get('/api/outreach-status')
def outreach_status():
    # Return persisted outreach status counts (do not assume default values for missing statuses)
    raw_status = getattr(data_service, 'status', {}) or {}
    if not raw_status:
        return {"outreach_status_available": False, "outreach_status": {}, "total_members": int(len(data_service.df))}
    counts = {}
    for v in raw_status.values():
        counts[v] = counts.get(v, 0) + 1
    return {"outreach_status_available": True, "outreach_status": counts, "total_members": int(len(data_service.df))}
