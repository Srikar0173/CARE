import urllib.request
s = urllib.request.urlopen('http://127.0.0.1:8000/outreach', timeout=5).read().decode()
print('OUTREACH_LEN', len(s))
print('HAS_DATA_MEMBER_ID', 'data-member-id' in s)
print('HAS_VIEW_MEMBER_CLASS', 'view-member' in s)
# check member page
mid = 'M08095'
mp = urllib.request.urlopen(f'http://127.0.0.1:8000/member?id={mid}', timeout=5).read().decode()
print('MEMBER_PAGE_OK', '<!--' not in mp[:50])
print(mp[:800])
