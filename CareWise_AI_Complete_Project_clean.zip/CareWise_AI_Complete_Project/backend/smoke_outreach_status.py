"""Focused API smoke test for the Outreach Status system."""
import json
import sys
import urllib.request
import urllib.error

BASE = "http://127.0.0.1:8000"
ALL_STATUSES = {"Pending", "In Progress", "Contacted", "Follow-up", "Completed"}
FAILURES = []

def fetch_json(url, method="GET", data=None):
    req = urllib.request.Request(url, method=method)
    body = None
    if data is not None:
        body = json.dumps(data).encode("utf-8")
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, body, timeout=10) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode("utf-8"))


def check(label, condition, detail=""):
    if condition:
        print(f"  PASS {label}")
    else:
        print(f"  FAIL {label} {detail}")
        FAILURES.append(f"{label}: {detail}")


print("=== 1. GET /api/outreach-status ===")
code, data = fetch_json(f"{BASE}/api/outreach-status")
check("status 200", code == 200, f"got {code}")
check("available true", data.get("outreach_status_available") is True)
counts = data.get("outreach_status", {})
check("all five statuses", set(counts.keys()) == ALL_STATUSES, f"keys={set(counts.keys())}")
check("total 10000", sum(counts.values()) == 10000, f"sum={sum(counts.values())}")
print(f"  counts = {counts}")

print("=== 2. All five statuses have positive counts ===")
for st in ALL_STATUSES:
    check(f"{st} > 0", counts.get(st, 0) > 0, f"count={counts.get(st, 0)}")

print("=== 3. Dashboard matches /api/outreach-status ===")
code, dash = fetch_json(f"{BASE}/api/dashboard")
check("dashboard 200", code == 200, f"got {code}")
check("dashboard available", dash.get("outreach_status_available") is True)
check("dashboard counts match", dash.get("outreach_status") == counts,
      f"dash={dash.get('outreach_status')} os={counts}")

print("=== 4. PATCH status update ===")
code, mem = fetch_json(f"{BASE}/api/members/M00001")
original = mem.get("outreach_status")
new_status = "Completed" if original != "Completed" else "Pending"
code, patch_resp = fetch_json(
    f"{BASE}/api/members/M00001/outreach-status",
    method="PATCH",
    data={"status": new_status},
)
check("patch 200", code == 200, f"got {code}")
check("patch applied", patch_resp.get("outreach_status") == new_status, str(patch_resp))
code, mem2 = fetch_json(f"{BASE}/api/members/M00001")
check("persisted", mem2.get("outreach_status") == new_status, f"got {mem2.get('outreach_status')}")
# restore
fetch_json(
    f"{BASE}/api/members/M00001/outreach-status",
    method="PATCH",
    data={"status": original},
)

print("=== 5. Invalid status rejected ===")
code, err = fetch_json(
    f"{BASE}/api/members/M00001/outreach-status",
    method="PATCH",
    data={"status": "NotARealStatus"},
)
check("rejected 400", code == 400, f"got {code}")
check("error message", "Invalid status" in str(err.get("detail", "")), str(err))

print("=== 6. Queue reflects backend status ===")
code, queue = fetch_json(f"{BASE}/api/priority-queue?page=1&page_size=5")
check("queue 200", code == 200, f"got {code}")
for item in queue.get("items", [])[:3]:
    mid = item.get("member_id")
    qstatus = item.get("outreach_status")
    code, detail = fetch_json(f"{BASE}/api/members/{mid}")
    dst = detail.get("outreach_status")
    check(f" {mid} queue==detail", qstatus == dst, f"queue={qstatus} detail={dst}")

print("=== 7. Status filter behavior ===")
code, filtered = fetch_json(f"{BASE}/api/members?status=In%20Progress&page_size=5")
check("filter 200", code == 200, f"got {code}")
check("filter total > 0", filtered.get("total", 0) > 0, "no In Progress members found")
for item in filtered.get("items", []):
    check("filtered==In Progress", item.get("outreach_status") == "In Progress",
          f"got {item.get('outreach_status')}")

print()
if FAILURES:
    print(f"SMOKE RESULT: FAIL ({len(FAILURES)} failures)")
    for f in FAILURES:
        print(f"  - {f}")
    sys.exit(1)
else:
    print("SMOKE RESULT: PASS (all checks passed)")
    print(f"\nExact /api/outreach-status response:")
    print(json.dumps({"outreach_status_available": True, "outreach_status": counts, "total_members": data.get("total_members")}, indent=2))
    sys.exit(0)