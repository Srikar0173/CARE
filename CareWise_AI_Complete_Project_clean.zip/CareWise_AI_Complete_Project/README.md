# CareWise AI — Complete Project

This is the clean local version: **one FastAPI server serves both the backend and the Stitch frontend**.

## Run in VS Code (Windows)

1. Open this project folder in VS Code.
2. Open a terminal.
3. Run:
   `cd backend`
4. Create a virtual environment:
   `python -m venv .venv`
5. Activate it:
   `.\.venv\Scripts\Activate.ps1`
6. Install:
   `pip install -r requirements.txt`
7. Start:
   `uvicorn app.main:app --host 127.0.0.1 --port 8000`
8. Open:
   `http://127.0.0.1:8000`

### Pages
- `/` Dashboard
- `/outreach` Outreach Queue
- `/member?id=Mxxxxx` Member 360
- `/analytics` Analytics
- `/call-guide?id=Mxxxxx` AI Call Guide
- `/docs` API docs
- `/health` Health

The frontend uses same-origin API calls. **Do not use Live Server** and do not change API URLs.

## Included real assets
- `backend/data/final_member_dataset.csv`
- `backend/data/outreach_status.json`
- `backend/models/final_model.joblib`
- `backend/models/shap_values.npy`
- `backend/models/metadata.json`
- `backend/models/model_metrics.csv`

Gemini is optional; without a `GEMINI_API_KEY`, the call guide uses the safe deterministic fallback.
